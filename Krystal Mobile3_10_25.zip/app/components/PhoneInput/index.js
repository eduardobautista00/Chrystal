import React from 'react';
import { View, Text } from 'react-native';
import { TextInput as PaperTextInput } from 'react-native-paper';
import { Picker } from '@react-native-picker/picker';
import { theme } from '../../core/theme'; // Import your theme if needed
import styles from './styles'; // Import styles from styles.js
import { useDarkMode } from '../../context/DarkModeContext';

export default function PhoneInput({ phone, setPhone, error, description  }) {
    const { isDarkMode } = useDarkMode();
    const countryCodes = [
        { label: '🇺🇸 US +1', value: '+1' },
        { label: '🇬🇧 UK +44', value: '+44' },
        { label: '🇦🇺 AU +61', value: '+61' },
        { label: '🇩🇪 DE +49', value: '+49' },
        { label: '🇫🇷 FR +33', value: '+33' },
        { label: '🇯🇵 JP +81', value: '+81' },
        { label: '🇨🇳 CN +86', value: '+86' },
        { label: '🇮🇳 IN +91', value: '+91' },
        { label: '🇿🇦 ZA +27', value: '+27' },
        { label: '🇰🇷 KR +82', value: '+82' },
        { label: '🇮🇹 IT +39', value: '+39' },
        { label: '🇪🇸 ES +34', value: '+34' },
        { label: '🇧🇷 BR +55', value: '+55' },
        { label: '🇲🇾 MY +60', value: '+60' },
        { label: '🇮🇩 ID +62', value: '+62' },
        { label: '🇨🇭 CH +41', value: '+41' },
        { label: '🇮🇪 IE +353', value: '+353' },
        { label: '🇵🇹 PT +351', value: '+351' },
        { label: '🇬🇷 GR +30', value: '+30' },
        { label: '🇸🇪 SE +46', value: '+46' },
        { label: '🇳🇴 NO +47', value: '+47' },
        { label: '🇩🇰 DK +45', value: '+45' },
        { label: '🇳🇱 NL +31', value: '+31' },
        { label: '🇳🇿 NZ +64', value: '+64' },
        { label: '🇴🇲 OM +968', value: '+968' },
        { label: '🇧🇭 BH +973', value: '+973' },
        { label: '🇰🇼 KW +965', value: '+965' },
        { label: '🇶🇦 QA +974', value: '+974' },
        { label: '🇦🇪 AE +971', value: '+971' },
        { label: '🇾🇪 YE +967', value: '+967' },
        { label: '🇪🇬 EG +20', value: '+20' },
        { label: '🇱🇰 LK +94', value: '+94' },
    ];

    const handlePhoneChange = (text) => {
        const fullValue = `${phone.countryCode || '+63'}${text}`;
        setPhone({
            ...phone,
            value: text,
            fullValue,
        });
    };

    return (
        <View style={styles.container}>
            <View style={styles.inputRow}>
                <View style={[styles.pickerContainer, error && styles.errorBorder]}>
                    <Picker
                        mode='dropdown'
                        selectedValue={phone.countryCode || '+63'}
                        onValueChange={(value) => {
                            const fullValue = `${value}${phone.value}`;
                            setPhone({
                                ...phone,
                                countryCode: value,
                                fullValue,
                            });
                        }}
                        style={[
                            styles.picker,
                            {
                                color: isDarkMode ? '#FFFFFF' : '#000000',
                                backgroundColor: isDarkMode ? '#1A1A1A' : '#FFFFFF',
                            },
                        ]}
                        dropdownIconColor={isDarkMode ? '#FFFFFF' : '#000000'}
                    >
                        <Picker.Item 
                            label="🇵🇭 PH +63" 
                            value="+63" 
                            color={isDarkMode ? '#FFFFFF' : 'gray'}
                            style={isDarkMode && { backgroundColor: '#1a1a1a' }}
                        />
                        {countryCodes.map((country) => (
                            <Picker.Item
                                key={country.value}
                                label={country.label}
                                value={country.value}
                                color={isDarkMode ? '#FFFFFF' : '#000000'}
                                style={isDarkMode && { backgroundColor: '#1a1a1a' }}
                            />
                        ))}
                    </Picker>
                </View>

                <View style={[styles.inputContainer, error && styles.errorBorder]}>
                    <PaperTextInput
                        style={[
                            styles.input,
                            isDarkMode && { 
                                backgroundColor: '#1A1A1A',
                            }
                        ]}
                        label="Phone Number"
                        value={phone.value}
                        onChangeText={handlePhoneChange}
                        keyboardType="phone-pad"
                        error={!!error}
                        mode="outlined"
                        theme={{
                            colors: {
                                text: isDarkMode ? '#FFFFFF' : '#000000',
                                placeholder: isDarkMode ? '#FFFFFF' : 'gray',
                                primary: theme.colors.primary,
                                background: isDarkMode ? '#1A1A1A' : '#FFFFFF',
                            }
                        }}
                        textColor={isDarkMode ? '#FFFFFF' : '#000000'}
                        
                    />
                </View>
            </View>
            {error ? <Text style={styles.errorText}>{error}</Text> : null}
        </View>
    );
}

