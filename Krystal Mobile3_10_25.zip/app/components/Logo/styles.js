import { StyleSheet } from 'react-native';
const styles = StyleSheet.create({
    image: {
      width: 250,
      height: 35,
      marginBottom: 8,
    },
  });
  

export default styles;