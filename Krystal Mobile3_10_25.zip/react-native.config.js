module.exports = {
    android: {
      packageName: 'com.ob_eduardo.Krystal', // Replace with your actual package name
    },
  };
  