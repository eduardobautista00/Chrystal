import React from "react";

import Background from "../../components/Background";

import AdminLayout from '../../layout/Admin';


export default function EditProfileScreen({ navigation }) {
  
  return (
    <AdminLayout>
        <Background>
    
        </Background>
    </AdminLayout>
  );
}
