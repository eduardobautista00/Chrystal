import { StyleSheet } from 'react-native';
const styles = StyleSheet.create({
    text: {
      fontSize: 15,
      lineHeight: 21,
      textAlign: "center",
      marginBottom: 12,
    },
  });
  

export default styles;