export function nameValidator(firstName) {
  if (!firstName) return "Please fill in this field."
  return ''
}